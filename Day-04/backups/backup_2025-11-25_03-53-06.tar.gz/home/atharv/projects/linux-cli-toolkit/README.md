# linux-cli-toolkit
A toolkit of CLI Scripts and Aliases that automate common admin tasks and demonstrate mastery of terminal workflows.
