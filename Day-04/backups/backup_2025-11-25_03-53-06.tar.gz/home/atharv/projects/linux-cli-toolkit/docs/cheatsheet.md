# Linux CLI Cheatsheet 1

## Navigation
- `cd -` → go back to last directory
- `pushd DIR`, `popd` → stack-based directory nav
- `ls -lh` → human-readable file sizes

## Search & History
- `Ctrl+R` → reverse search history
- `!!` → run last command
- `!$` → last argument of previous command
- `history | grep "pattern"`

## File Management
- `find . -type f -name "*.log"`
- `du -sh * | sort -hr | head`

## Process & Monitoring
- `top`, `htop`
- `ps aux | grep "process"`
- `kill -9 PID`

