#!/bin/bash

# Author:        Atharv Sharma
# Date Created:  12/09/2025
# Date Modified: 12/09/2025

# Description: Install toolkit to ~/bin

set -e

TARGET=~/bin
mkdir -p $TARGET
cp bin/* $TARGET/
chmod +x $TARGET/

echo "Sucessfully Installed toolkit to $TARGET"
echo "Make sure $TARGET is in your path"
