#!/bin/bash
set -e
echo "Running all tests..."
bash test_system_info.sh
bash test_disk_report.sh
bash test_find_dups.sh
bash test_watchlog.sh
echo "All tests passed ✅"
