#!/bin/bash
../bin/disk_report.sh > /dev/null
if [ $? -eq 0 ]; then
	echo "disk_report.sh: PASS"
else
	echo "disk_report.sh: FAIL"
	exit 1
fi
