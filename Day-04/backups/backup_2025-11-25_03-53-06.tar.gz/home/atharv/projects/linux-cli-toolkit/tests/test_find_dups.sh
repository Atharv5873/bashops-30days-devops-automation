#!/bin/bash
../bin/find_dups.sh > /dev/null
if [ $? -eq 0 ]; then
	echo "find_dups.sh: PASS"
else
	echo "find_dups.sh: FAIL"
	exit 1
fi
