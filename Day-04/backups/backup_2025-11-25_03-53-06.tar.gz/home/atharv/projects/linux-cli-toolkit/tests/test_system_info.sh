#!/bin/bash
../bin/system_info.sh > /dev/null
if [ $? -eq 0 ]; then
	echo "system_info.sh: PASS"
else
	echo "system_info.sh: FAIL"
	exit 1
fi
