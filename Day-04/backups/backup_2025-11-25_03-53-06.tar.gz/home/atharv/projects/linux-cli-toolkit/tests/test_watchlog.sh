#!/bin/bash
set -e

LOGFILE="test_syslog.log"
: > "$LOGFILE"   

../bin/watchlog.sh "TEST" "$LOGFILE" &
PID=$!

echo "BOOT COMPLETED" >> "$LOGFILE"
echo "TEST PATTERN MATCH" >> "$LOGFILE"


sleep 2
kill $PID || true

if grep -q "TEST PATTERN MATCH" ~/alerts.log; then
  echo "watchlog.sh test passed"
else
  echo "watchlog.sh test failed"
  exit 1
fi
